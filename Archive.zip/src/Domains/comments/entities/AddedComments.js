class AddedComments {
  constructor({ id, body, userId }) {
    this.id = id;
    this.content = body;
    this.owner = userId;
  }
}

module.exports = AddedComments;

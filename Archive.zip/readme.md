ddd pattern submission
